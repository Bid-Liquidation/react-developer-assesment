function App() {
  return (
    <>
      <h1>React Developer Assesment</h1>

      <p style={{ fontSize: 24 }}>
        Welcome to the React Developer Assesment! Please follow the instructions
        in <span style={{ fontWeight: 700 }}>README.md</span> to complete the
        task.
      </p>
    </>
  );
}

export default App;
